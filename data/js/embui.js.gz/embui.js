function changeCSS(cssFile, cssLinkIndex) {

    var oldlink = document.getElementsByTagName("link").item(cssLinkIndex);

    var newlink = document.createElement("link");
    newlink.setAttribute("rel", "stylesheet");
    newlink.setAttribute("type", "text/css");
    newlink.setAttribute("href", cssFile);

    document.getElementsByTagName("head").item(0).replaceChild(newlink, oldlink);
}

function setDynCSS(url) {
        if (!arguments.length) {
                url = (url = document.cookie.match(/\bdyncss=([^;]*)/)) && url[1];
                if (!url) return '';
        }
        document.getElementById('dyncss').href = url;
        var d = new Date();
        d.setFullYear(d.getFullYear() + 1);
        document.cookie = ['dyncss=', url, ';expires=', d.toGMTString(), ';path=/;'].join('');
        return url;
}

setDynCSS();
// 
function refreshPage(){
	let currnt = window.location.href;
	console.log("Curretn location", currnt);
	let currntPage = {};
	let idx = currnt.indexOf('?');
	if (idx) {
		console.log("CHECK", currnt.slice(idx+1));
		currntPage[currnt.slice(idx+1)] = null;
	}
	ws.send_post({main:null});
	ws.send_post(currntPage);
}

// Дополнительный обработчик для кнопки переключения языка
document.addEventListener('change', (e)=>{
	if(e.target!=document.getElementById('lang')) return;
	
	console.log('--| switch lang ru!');
	langs = document.getElementById('lang').value;
	localStorage.setItem('lang', langs);
	loadLang();
	// updateLang();
	// refreshPage();
});



/**
 * loadLang() function. Вызывается для переключения между словарями
 * Если была нажата кнопка смены языка - возьмет значение оттуда, если нет - возьмет значение из конфига
 */
function loadLang(){
	let checkLocalStorage = localStorage.getItem('lang');
	if (checkLocalStorage !== null){
		langs = checkLocalStorage;
		console.log("Local Storage lang", checkLocalStorage, "langs", langs);
	}
	else 
		langs = "eng";

	getLang();
}
loadLang();


let glossary = {};
/**
 * getLang() function. Вызывается для переключения между словарями
 * Если была нажата кнопка смены языка - возьмет значение оттуда, если нет - возьмет значение из конфига
 */
function getLang(){
	httpRequest = new XMLHttpRequest();
	httpRequest.overrideMimeType('application/json');
	httpRequest.onload = ()=>{
		// if (this.readyState == 4 && this.status == 200) {
			glossary = JSON.parse(httpRequest.responseText);
			refreshPage();
		// }
	}
	httpRequest.open('GET', 'local/' + langs + '.json', true);
	httpRequest.send(null);
}

var go = function(param, context){
	if (!arguments.length) return new GO(document);
	if (typeof param == "string") return (new GO(context || document)).go(param);
	if (typeof param == "undefined") return new GO();
	return new GO(param);
}

go.formdata = function(form){
	var controls = {},
	checkValue = function(element){
		switch (element.type.toLowerCase()){
			case 'checkbox':		// use "1" as a value for 'checked' boxes  
				return element.checked?	"1" : "0";
			case 'radio':
				if(element.checked) return element.value;
				break;
			case 'hidden':
				if(element.id == "devicedatetime"){
					var m = new Date(Date.now());
					var dateString =
					    m.getUTCFullYear() + "-" +
					    ("0" + (m.getMonth()+1)).slice(-2) + "-" +
					    ("0" + m.getDate()).slice(-2) + "T" +
					    ("0" + m.getHours()).slice(-2) + ":" +
					    ("0" + m.getMinutes()).slice(-2) + ":" +
					    ("0" + m.getSeconds()).slice(-2);
					//console.log(dateString);
				} else return element.value;
				return dateString;
				break;
			default:
				return element.value;
		}
	};

	for(var i = 0; i < form.length; i++){
		var el = form[i];
		if (el.disabled) continue;
		switch (el.tagName.toLowerCase()){
			case 'input':
				var val = checkValue(el);
				if (typeof val != "undefined") controls[el.name || el.id]= val;
				break;
			case 'textarea':
			case 'select':
				controls[el.name || el.id]= el.value;
				break;
			default:
				continue;
		}
	}
	return controls;
}

go.linker = function(fn,th){
	var arg = Array.prototype.slice.call(arguments,2);
	return function(){ return fn.apply(th, Array.prototype.slice.call(arguments).concat(arg)); };
}
go.listevent = function(el, evn, fn, opt){
	var self = ((opt instanceof Object)? opt.self : 0) || this;
	el = (el instanceof Array)? el : [el];
	evn = (evn instanceof Array)? evn : [evn];
	var rfn = function(arg){
		return function(e){
			e = e || event;
			var a = arg.slice(); a.unshift(e);
			var retval = fn.apply(self, a);
			if (typeof retval !== 'undefined' && !retval){
				if(e.preventDefault) e.preventDefault();
				else e.returnValue = false;

				if(e.stopPropagation) e.stopPropagation();
				else e.cancelBubble = true;
			}
			return retval;
		};
	}([].slice.call(arguments,4));

	for(var i = 0; i < el.length; i++) for(var j = 0; j < evn.length; j++){
		if(window.addEventListener){
			el[i].addEventListener(evn[j], rfn, opt);
		}else{
			el[i].attachEvent("on"+evn[j], rfn);
		}
	}
};
go.path = function(el, p, st){
	p = (p instanceof Array)? p : p.split(".");
	var i = p.shift();
	if (!i && st && st._parent) return this.path(st._parent._this, p, st._parent);
	if (i == "_this" || i == "_this2" || i == "_this3") {
		return p.length? this.path(st._this, p, st) : el;
	}
	if (i == "_index") return st._index;
	if (i == "_key") return st._key;
	if (i == "_val") return st._val;

	if (!el) return el;
	if (el[i] instanceof Object && p.length) return this.path(el[i], p, st);
	return el[i];
}
go.merge = function(base, data, idx) {
	for (var i in data) {
		var id = idx? idx + parseInt(i) : i;
		if (typeof data[i] == 'object') {
			if (typeof base[id] != 'object') base[id] = (data[i] instanceof Array)? [] : {};
			this.merge(base[id], data[i], (i == "block")? data.idx : undefined);
		} 
		else if (id == "label" || id == "blabel" || id == "drawClear") {   // "blabel" и "drawClear" касаются только лампы, но пусть временно поживут тут
			if (!isNaN(data[i])){
				base[id] = glossary[Number(data[i])];
			}
			else {
				base[id] = data[i];
			}
		}
		else base[id] = data[i];
	}
	return base;
}
go.eval = function(th, data) {
	return (function(){ return eval(data); }).call(th);
}

var GO = function(context){
	if (context) {
		context = ((context instanceof Object || typeof context == 'object') &&
			typeof context.length !== 'undefined' && context.nodeType == undefined
		)? context : [context];
		for(var i = 0; i < context.length; i++) this.push(context[i]);
	}
}
GO.prototype = new Array();
;(function($_){
	$_._alias = {},
	$_.alias = function(alias){
		for(var a in alias){
			$_[a] = function(path){
				path = (typeof path == 'string')? path.split(".") : path;
				return function(){
					var m = null, out = new GO([]);
					for (var i = 0; i < this.length; i++) {
						if (typeof path == 'function') {
							m = path.apply(this[i], arguments);
						} else {
							var obj = this[i], len = path.length - 1;
							for (var j = 0; obj && j < len; j++) obj = obj[path[j]];
							if (obj && typeof obj[path[len]] !== 'undefined') {
								if (typeof obj[path[len]] == 'function' || typeof obj[path[len]].toString == 'undefined'){
									m = obj[path[len]].apply(obj, arguments);
								} else if (typeof obj[path[len]] == 'object'){
									if (arguments.length == 2) obj[path[len]][arguments[0]] = arguments[1];
									m = this[i];//obj[path[len]];
								} else {
									if (arguments.length == 1) obj[path[len]] = arguments[0];
									m = this[i];//obj[path[len]];
								}
							}
						}
						if (m === null) continue;
						if (m === undefined) m = this[i];
						if (!m || typeof m === 'string' || typeof m === 'function' || typeof m.length === 'undefined') {
							m = [m];
						}
						for (var n = 0; n < m.length; n++) out.push(m[n]);
					}
					return out;
				};
			}(alias[a]);
			$_._alias[a] = alias[a];
		}
		return this;
	}
	$_.alias({
		'go':'querySelectorAll', 'query':'querySelectorAll',
		'attr':'getAttribute','sattr':'setAttribute','rattr':'removeAttribute',
		'byid':'getElementById', 'bytag':'getElementsByTagName',
		'byname':'getElementsByName', 'byclass':'getElementsByClassName',
		'css':'style', 'style':'style', 'display':'style.display',
		'left': 'style.left', 'right': 'style.right', 'top': 'style.top', 'bottom': 'style.bottom',
		'height': 'style.height', 'width': 'style.width',
		'innerHTML': 'innerHTML', 'src': 'src', 'href': 'href',
		'addClass':'classList.add', 'removeClass':'classList.remove', 'className':'className',
		'toggleClass':'classList.toggle', 'contClass':'classList.contains',
		'each': function(fn){
			var r = fn.apply(this, [].slice.call(arguments,1));
			return (typeof r != 'undefined')? r : this;
		},
		'exec': function(){ return this.apply(arguments); },
		'event': function(n,dt,ps) {
			var evt = null;
			ps = ps || {bubbles: false, cancelable: true, detail: undefined, view: undefined};
			ps.detail = dt;
			if (typeof window.CustomEvent != "function") {
				evt = document.createEvent('CustomEvent');
				evt.initCustomEvent(n, ps.bubbles, ps.cancelable, ps.detail);
			} else {
				evt = new CustomEvent(n, ps);
			}
			this.dispatchEvent(evt);
			return this;
		},
		'bind': function(ev, fn){
			return go.listevent.apply(this, [this, ev, fn, {self: this}].concat([].slice.call(arguments, 2)));
		},
		'find': function(k,v){
			return (typeof this == 'object' && this[k] && (!v || this[k] === v))? this : null;
		},
		'id': function(v){
			return (typeof this == 'object' && this["id"] === v)? this : null;
		},
		'set': function(k,v){
			if (typeof this == 'object') {
				if (typeof k == 'object') {
					for (var i in k) this[i] = k[i];
				} else this[k] = v;
				return this;
			}
			return null;
		},
		'cstyle': function(ps){
			if (typeof ps == 'object') for (var i in ps) {
				var st = i.split("-");
				for (var n = 1; n < st.length; n++) st[n] = st[n][0].toUpperCase() + st[n].slice(1);
				this.style[st.join("")] = ps[i];
			}
			return [window.getComputedStyle? window.getComputedStyle(this, (typeof ps == 'string')? ps : "") : this.currentStyle];
		},
		'showhide': function(){
			if (!this.style.display) this.style.display = go(this).cstyle()[0].display;
			this.style.display = (this.style.display === "none")? "block" : "none";
			return this;
		},
		'clone': function(){ return this.cloneNode(true); },
		'fragment': function(el){ return document.createDocumentFragment();	},
		'remove': function(){ var p = this.parentNode; p.removeChild(this); return this; },
		'clear': function(){ while(this.firstChild) this.removeChild(this.firstChild); return this; },
		'append': function(el){
			el = (el instanceof Array)? el : [el];
			for(var i = 0; i < el.length; i++) this.appendChild(el[i]);
			return this;
		},
		'prepend': function(el){
			el = (el instanceof Array)? el : [el];
			for(var i =  el.length; i > 0; i--) this.insertBefore(el[i-1], this.firstChild);
			return this;
		},
		'replace': function(el){
			el = (el instanceof Array)? el : [el];
			for(var i = 0; i < el.length; i++) {
				this.parentNode.insertBefore(el[i], this);
				if (i == el.length - 1) this.parentNode.removeChild(this);
			}
			return this;
		},
		'before': function(el){
			el = (el instanceof Array)? el : [el];
			for(var i =  el.length; i > 0; i--) this.parentNode.insertBefore(el[i-1], this);
			return this;
		},
		'after': function(el, t){
			el = (el instanceof Array)? el : [el];
			var ns = t? this.nextSibling : this.nextElementSibling;
			if (ns) {
				for(var i = el.length; i > 0; i--) this.parentNode.insertBefore(el[i-1], ns);
			} else {
				for(var i = 0; i < el.length; i++) this.parentNode.appendChild(el[i]);
			}
			return this;
		},
		'create': function(tg,a1,a2){
			tg = document.createElement(tg);
			var dt = (typeof a2 == "string")? a2 : ((typeof a1 == "string")? a1 : 0),
			at = (typeof a1 == "object")? a1 : 0;
			if(dt) tg.innerHTML = dt;
			if(at) for(var i in at) tg.setAttribute(i, at[i]);
			if (this !== document) this.appendChild(tg);
			return tg;
		},
		'html': function(vl,ap){ if(ap) this.innerHTML += vl; else this.innerHTML = vl; return this; },
		'children': function(){ return this.children; },
		'nodes': function(type){
			return (this.nodeType == (type? type : 1))? this : null;
		}
	});
}(GO.prototype));

var mustache = function(tmpl,func){
	this.nevent = 0; this.scope = [];
	this._tmpl = (typeof tmpl == 'string')? tmpl : tmpl.innerHTML.replace(/[\r\t\n]/g, "");
	this._func = func || this._func || {};

	this._func.exec = this._func.exec || function(d,fn){
		var arg = [].slice.call(arguments, 2),
		out = 'data-musfun'+this.nevent+'="'+fn+'" '+
		'data-musarg'+this.nevent+'="'+escape(JSON.stringify(arg))+'"';
		this.nevent++;
		return out;
	};
	this._func.onevent = this._func.onevent || function(d){
		var arg = [].slice.call(arguments, 1);
		arg.unshift(d, "event");
		return this._func.exec.apply(this, arg);
	};
	this._func.event = this._func.event || function(th,ev,fn){
		var arg = [].slice.call(arguments, 3);
		fn = th._func[fn];
		if (fn) go.listevent(this, ev.split(","), function(e){
			var a = arg.slice(); a.unshift(e); return fn.apply(this, a);
		}, {self: this});
	};
	this._func.if = this._func.if || function(d){
		for (var i = 1; i < arguments.length; i++) if (!arguments[i]) return 0;
		return 1;
	};
	this._func.if2 = this._func.if,
	this._func.if3 = this._func.if,
	this._func.calc = this._func.calc || function(d){
		return [].slice.call(arguments, 1).join();
	};
}
;(function($_){
	var cont = document.createElement("div"),
	rgobj = /\{\{(@|#|!|\^)([a-z0-9_.]+?)(?:\s+(.+?))?\}\}([\s\S]*?)\{\{\/\2\}\}/gi,
	rgitem = /\{\{(!|>)?([a-z0-9_.]+?)(?:\s+(.+?))?\}\}/gi,
	rgparam = /\s*,\s*/gi,
	rgfield = /[a-z0-9_.]+|".*?"|'.*?'|`.*?`/gi,
	strcon = ['true','false','null','undefined','typeof','instanceof','Array','Object'];

	$_._parse_param = function(val, data, stack){
		var m = val.match(rgfield), s = val.split(rgfield), out = "";
		while (s && (val = s.shift()) != undefined) {
			out += val;
			if (m && (val = m.shift())) {
				if (strcon.indexOf(val) != -1 || val[0] == '"' || val[0] == "'" || Number(val) == Number(val)) out += val;
				else if (val[0] == "`") out += val.substr(1, val.length - 2);
				else {
					this.scope.push(go.path(data, val, stack));
					out += "this["+(this.scope.length-1)+"]";
				}
			}
		}
		try{ return go.eval(this.scope, out); }catch(e){ return undefined; }
	}
	$_._parse_item = function(tmpl, data, stack){
		tmpl = (tmpl || "").replace(rgitem, go.linker(function(all, pref, name, argum){
			var arg = argum? argum.split(rgparam) : [], out;
			for (var i = 0; i < arg.length; i++) arg[i] = this._parse_param(arg[i], data, stack);
			if (pref == "!") return "";
			if (pref == ">"){
				var el = document.getElementById(name), dt = arg.length? arg[0] : data;
				return el? (new mustache(el, this._func)).parse(dt, this, stack) : "";
			}
			if (this._func[name]) {
				arg.unshift(data);
				return this._func[name].apply(this, arg);
			}
			out = go.path(data, name, stack);
			return (typeof out != 'undefined')? out : "";
		}, this));
		return tmpl;
	}
	$_._parse_obj = function(tmpl, data, stack){
		tmpl = (tmpl || "").replace(rgobj, go.linker(function(all, pref, name, argum, body){
			var out = body || argum || "", value = go.path(data, name, stack);
			if (pref == "!") return "";
			if (typeof value == 'function' || this._func[name]) {
				var arg = (body && argum)? argum.split(rgparam) : [];
				for (var i = 0; i < arg.length; i++) arg[i] = this._parse_param(arg[i], data, stack);
				arg.unshift(data);
				if (pref == "@") arg.unshift(body);
				var res = (this._func[name] || value).apply(this, arg);
				if (pref == "#") out = res? this._parse_obj(out, data, stack) : "";
				else if (pref == "^") out = res? "" : this._parse_obj(out, data, stack);
				else out = res;
			} else if (value instanceof Array) {
				if (pref != "^" && !value.length) return "";
				if (pref == "^" && value.length) return "";
				var res = "", stk = {_this:data, _parent:stack};
				for (var i = 0; i < value.length; i++) {
					stk._index = i; stk._val = value[i];
					var tmp = this._parse_obj(out, value[i], stk);
					res += this._parse_item(tmp, value[i], stk);
				}
				out = res;
			} else if (value instanceof Object) {
				if (!value && pref == "#" || value && pref == "^") return "";
				var stk = {_this:data, _parent:stack};
				if (pref == "#" || pref == "^") {
					out = this._parse_obj(out, value, stk);
					out = this._parse_item(out, value, stk);
				} else {
					var res = "", n = 0;
					for (var i in value) {
						stk._index = n++; stk._key = i;
						var tmp = this._parse_obj(out, value[i], stk);
						res += this._parse_item(tmp, value[i], stk);
					}
					out = res;
				}
			} else {
				if (!value && pref == "#" || value && pref == "^") return "";
				out = this._parse_obj(out, data, stack);
				out = this._parse_item(out, data, stack);
			}

			return out;
		}, this));
		return tmpl;
	}
	$_.parse = function(data, parent, stack){
		this.nevent = (typeof parent == "object")? parent.nevent : 0;
		stack = stack || {_this:data};
		var out = this._parse_obj(this._tmpl, data, stack);
		out = this._parse_item(out, data, stack);
		if (parent) {
			if (typeof parent == "object") parent.nevent = this.nevent;
			return out;
		}
		cont.innerHTML = out;
		for (var i = 0; i <= this.nevent; i++){
			go("[data-musfun"+i+"]",cont).each(function(th){
				var fn = th._func[this.getAttribute("data-musfun"+i)],
				arg = JSON.parse(unescape(this.getAttribute("data-musarg"+i)));
				this.removeAttribute("data-musarg"+i);
				this.removeAttribute("data-musfun"+i);
				try{ if (fn){ arg.unshift(th); fn.apply(this, arg); } }catch(e){}
			}, this);
		}
		return [].slice.call(cont.childNodes);
	}
}(mustache.prototype));

var wbs = function(url){
	var ws = null, frame = {}, connected = false, lastmsg = null, to = null,
	open = function(fnopen, fnerror){
		ws = new WebSocket(url);
		ws.onerror = function(err){
			console.log("WS Error", err);
			if (fnerror) fnerror(err);
			if (typeof out.onerror== "function") {
				try{ out.onerror(); } catch(e){ console.log('Error onerror', e); }
			}
		}
		ws.onopen = function(){
			console.log("WS Open");
			connected = true;
			if (fnopen) fnopen();
			if (typeof out.onopen== "function") {
				try{ out.onopen(); } catch(e){ console.log('Error onopen', e); }
			}
		},
		ws.onclose = function(){
			console.log("WS Close");
			connected = false;
			if (typeof out.onclose== "function") {
				try{ out.onclose(); } catch(e){ console.log('Error onclose', e); }
			}
		}
		ws.onmessage = function(msg){
			try{ msg = JSON.parse(msg.data); } catch(e){ console.log('Error message', e); return; }
			console.log('Received message:', msg);
			if (!(msg instanceof Object)) return;
			if (msg.section) {
				if (!frame[msg.section]) frame[msg.section] = {};
				go.merge(frame[msg.section], msg);
				if (msg.final) {
					receiv_msg(frame[msg.section]);
					delete frame[msg.section];
				}
			} else {
				receiv_msg(msg);
			}
		}
	},
	receiv_msg = function(msg){
		console.log('Received packet:', msg);
		if (msg.pkg && typeof out["on"+msg.pkg] == "function"){
			try{ out["on"+msg.pkg](msg); } catch(e){ console.log('Error on'+msg.pkg, e); }
		}
	},
	send = function(msg){ try{ ws.send(msg); }catch(e){} },
	send_msg = function(msg){
		console.log('Sending message:', msg);
		try{ lastmsg = JSON.stringify(msg); } catch(e){ console.log('Error stringify', e); return; }
		if (connected) send(lastmsg);
	},

	out = {
		connect: function(){
			console.log("WS Connect");
			ws = null;
			if (to) clearTimeout(to);
			to = setTimeout(function(){open(function(){
				to = null;
				if (lastmsg) send(lastmsg);
			})}, 500);
		},
		send_post: function(dt){
			send_msg({pkg:"post", data:dt});
		}
	};
	return out;
}

var global = {menu_id:0, menu: [], value:{}};

var render = function(){
	var tmpl_menu = new mustache(go("#tmpl_menu")[0],{
		on_page: function(d,id) {
			out.menu_change(id);
		}
	}),
	fn_section = {
		on_input: function(d, id){
			var value = this.value, type = this.type;
			if (type == "range") go("#"+id+"-val").html(": " + value);
			if (type == "text" || type == "password") go("#"+id+"-val").html(" ("+value.length+")");
			if (type == "color") go("#"+id+"-val").html(" ("+value+")");
			if (this.id != id){
				custom_hook(this.id, d, id);
			}
		},
		on_change: function(d, id) {
			var value = this.value, type = this.type;
			if (type == "checkbox"){
				var chbox=document.getElementById(id);
				if (chbox.checked) value = "1";		// send 'checked' state as "1"
				else value = "0";
			}
			if (this.id != id){
				custom_hook(this.id, d, id);
			}
			var data = {}; data[id] = (value !== undefined)? value : null;
			ws.send_post(data);
		},
		on_showhide: function(d, id) {
			go("#"+id).showhide();
		},
		on_submit: function(d, id, val) {
			var form = go("#"+id), data = go.formdata(go("input, textarea, select", form));
			data[id] = val || null;
			ws.send_post(data);
		}
	},
	tmpl_section = new mustache(go("#tmpl_section")[0], fn_section),
	tmpl_section_main = new mustache(go("#tmpl_section_main")[0], fn_section),
	tmpl_content = new mustache(go("#tmpl_content")[0], fn_section),
	out = {
		lockhist: false,
		history: function(hist){
			history.pushState({hist:hist}, '', '?'+hist);
		},
		menu_change: function(menu_id){
			global.menu_id = menu_id;
			this.menu();
			go("#main > div").display("none");
			// go("#main #"+menu_id).display("block");
			var data = {}; data[menu_id] = null
			ws.send_post(data);
		},
		menu: function(){
			go("#menu").clear().append(tmpl_menu.parse(global));
		},
		section: function(obj){
			if (obj.main) {
				go("#main > section").remove();
				go("#main").append(tmpl_section_main.parse(obj));
				if (!out.lockhist) out.history(obj.section);
			} else {
				go("#"+obj.section).replace(tmpl_section.parse(obj));
			}
		},
		make: function(obj){
			var frame = obj.block;
			if (!obj.block) return;
			for (var i = 0; i < frame.length; i++) if (typeof frame[i] == "object") {
				if (frame[i].section == "menu") {
					global.menu =  frame[i].block;
					if (!isNaN(obj.app)){
						document.title = glossary[Number(obj.app)] + " - " + obj.mc;
						global.app = glossary[Number(obj.app)];
					}
					else {
						document.title = obj.app + " - " + obj.mc;
						global.app = obj.app;
					}
					global.mc = obj.mc;
					global.ver = obj.ver;
					global.lan = langs;
					if (!global.menu_id) global.menu_id = global.menu[0].value
					this.menu();
				} else
				if (frame[i].section == "content") {
					for (var n = 0; n < frame[i].block.length; n++) {
						go("#"+frame[i].block[n].id).replace(tmpl_content.parse(frame[i].block[n]));
					}
				} else {
					this.section(frame[i]);
				}
			}
			out.lockhist = false;
		},
		// обработка данных, полученных в пакете "pkg":"value"
		// блок разбирается на объекты по id и их value применяются к элементам шаблона на html странице
		value: function(obj){
			var frame = obj.block;
			if (!obj.block) return;
			for (var i = 0; i < frame.length; i++) if (typeof frame[i] == "object") {
				var el = go("#"+frame[i].id);
				if (el.length) {
					if (frame[i].html) {	// update placeholders in html template, like {{value.pMem}}
						global.value[frame[i].id] = frame[i].value
						el.html(frame[i].value);
					} else{
						el[0].value = frame[i].value;
						if (el[0].type == "range") go("#"+el[0].id+"-val").html(": "+el[0].value);
						// проверяем чекбоксы на значение вкл/выкл
						if (el[0].type == "checkbox") {
							// allow multiple types of TRUE value for checkboxes
							el[0].checked = (frame[i].value == "1" || frame[i].value == 1 || frame[i].value == true || frame[i].value == "true" );
							//console.debug("processing checkbox num: ", i, "val: ", frame[i].value);
						}
					}
				}
			}
		}
	};
	return out;
};

/**
 * rawdata callback - Stub function to handle rawdata messages from controller
 * Data could be sent from the controller via json_frame_custom(String("rawdata")) method
 * and handled in a custom user js script via redefined function
 */
function rawdata_cb(msg){
    console.log('Got raw data, redefine rawdata_cb(msg) func to handle it.', msg);
}

/**
 * User Callback for xload() function. Вызывается после завершения загрузки внешних данных, но
 * перед предачей объекта обработчику шаблона. Если коллбек возвращает false, то вызов шаблонизатора не происходит.
 * Может быть перенакрыта пользовательским скриптом для доп обработки загруженных данных
 */
function xload_cb(obj){
//    console.log('redefine xload_cb(obj) func to handle it.', msg);
	return true;
}

/**
 * @brief - Loads JSON objects via http request
 * @param {*} url - URI to load
 * @param {*} ok - callback on success
 * @param {*} err - callback on error
 */
function ajaxload(url, ok, err){
	var xhr = new XMLHttpRequest();
	xhr.overrideMimeType("application/json");
	xhr.responseType = 'json';
	xhr.open('GET', url, true);
	xhr.onreadystatechange = function(){
		if (xhr.readyState == 4 && xhr.status == "200") {
			ok && ok(xhr.response);
		} else if (xhr.status != "200"){
			err && err(xhr.status)
		}
	};
	xhr.send(null);
}

/**
 * 	"pkg":"xload" messages are used to make ajax requests for external JSON objects that could be used as data/interface templates
 * используется для загрузки контента/шаблонов из внешних источников - "флеш" контроллера, интернет ресурсы с погодой и т.п.,
 * объекты должны сохранять структуру как если бы они пришли от контроллера. Просмариваются рекурсивно все секции у которых есть ключ 'url',
 * этот урл запрашивается и результат записывается в ключ 'block' текущей секции. Ожидается что по URL будет доступен корректный JSON.
 * Результат передается в рендерер и встраивается в страницу /Vortigont/
 * @param { * } msg - framework content/interface object
 * @returns 
 */
function xload(msg){
    if (!msg.block){
        console.log('Message has no data block!');
        return;
    }

	console.log('Run deepfetch');
	deepfetch(msg.block).then(() => {
		 //console.log(msg);
		 if (xload_cb(msg)){
			var rdr = this.rdr = render();	// Interface rederer to pass updated objects to
			rdr.make(msg);
			updateLang();   // Вызываем для перевода внешних ресурсов
		 }
	})
}

/**
 * async function to traverse object and fetch all 'url' in sections,
 * this must be done in async mode till the last end, since there could be multiple recursive ajax requests
 * including in sections that were just fetched /Vortigont/
 * @param {*} obj - EmbUI data object
 */
async function deepfetch (obj) {
	for (let i = 0; i < obj.length; i++) if (typeof obj[i] == "object") {
		var section = obj[i];
		if (section.url){
			console.log('Fetching URL"' + section.url);
			await new Promise(next=> {
					ajaxload(section.url,
						function(response) {
							section['block'] = response;
							delete section.url;	// удаляем url из элемента т.к. работает рекурсия
							// пробегаемся рекурсивно по новым/вложенным объектам
							if (section.block && typeof section.block == "object") { 
								deepfetch(section.block).then(() => {
									//console.log("Diving deeper");
									next();
							   })
							} else {
								next();
							}
						},
						function(errstatus) {
							//console.log('Error loading external content');
							next();
						}
					);
			})
		} else if ( section.block && typeof section.block == "object" ){
			await new Promise(next=> {
				deepfetch(section.block).then(() => {
					next();
				})
			})			
		}
	}
}


window.addEventListener("load", function(ev){
	var rdr = this.rdr = render();
	var ws = this.ws = wbs("ws://"+location.host+"/ws");
	//var ws = this.ws = wbs("ws://embuitst/ws");
	ws.oninterface = function(msg) {
		rdr.make(msg);
	}
	ws.onvalue = function(msg){
		rdr.value(msg);
	}
	ws.onclose = ws.onerror = function(){
		ws.connect();
	}
	ws.connect();

	// any messages with "pkg":"rawdata" are handled here bypassing interface/value handlers
	ws.onrawdata = function(mgs){
		rawdata_cb(mgs);
	}

	// "pkg":"xload" messages are used to make ajax requests for external JSON objects that could be used as data/interface templates
	ws.onxload = function(mgs){
		xload(mgs);
	}

	var active = false, layout =  go("#layout");
	go("#menuLink").bind("click", function(){
		active = !active;
		if (active) layout.addClass("active");
		else layout.removeClass("active");
		return false;
	});
	go("#layout, #menu, #main").bind("click", function(){
		active = false;
		if (layout.contClass("active")[0]) {
			layout.removeClass("active");
			return false;
		}
	});
	
	// touch swipe left support
	let strX, strY, strT;
	go("body").bind("touchstart", function(e){
	  let t = e.changedTouches[0];
	  strX = t.pageX;
	  strY = t.pageY;
	  strT = new Date().getTime();
	}, {passive: true});

	go("body").bind("touchend", function(e){
	    let t = e.changedTouches[0],
	        elapsedT = new Date().getTime() - strT;
	    if (elapsedT <= 500 && Math.abs(t.pageY - strY) <= 75) {
	      if (!active && t.pageX - strX >= 50) {
		layout.addClass("active"); active = true;
	      }
	    }
	}, false);

}.bind(window));

window.addEventListener("popstate", function(e){
	if (e = e.state && e.state.hist) {
		rdr.lockhist = true;
		var data = {}; data[e] = null;
		ws.send_post(data);
	}
});

window.addEventListener("click", function(){
	document.getElementById('lang').value = langs;
});/**
 * Эта часть отвечает за перевод кешированных JSON
 * В фреймворке не используется, но для лампы нужна для переводов списка эффектов
 * Применяется после вызова deepfetch()
 */
lang = (function init_lang() {
var BODY = document.body,
//тело документа
LANG_HASH = {},
//собственно, результирующий хэш
LANG_HASH_LIST = [],
//список загружаемых словарей
LANG_HASH_INDEX = {},
//список имён словарей
LANG_HASH_USER = {},
//пользовательский словарь
LANG_HASH_SYSTEM = {},
//системный словарь
LANG_QUEUE_TO_UPDATE = [],
//очередь элементов для обновления
LANG_PROPS_TO_UPDATE = {},
//перечень имён для обновления
LANG_UPDATE_LAST = -1,
//индекс последнего обновлённого элемента
LANG_UPDATE_INTERVAL = 0,
//интервал обновления
LANG_JUST_DELETE = false; //неперестраивание хэша при удалении словаря
var hash_rebuild = function hash_rebuild() { //функция перестраивания хэша
    var obj = {};
    obj = lang_mixer(obj, LANG_HASH_USER);
    for (var i = 0, l = LANG_HASH_LIST.length; i < l; i++)
    obj = lang_mixer(obj, LANG_HASH_LIST[i]);
    LANG_HASH = lang_mixer(obj, LANG_HASH_SYSTEM);
},
lang_mixer = function lang_mixer(obj1, obj2) { //функция расширения свойствами
    for (var k in obj2)
    obj1[k] = obj2[k];
    return obj1;
},
lang_update = function lang_update(data) { //функция, инициирующая обновление
    switch (typeof data) {
    default:
        return;
    case "string":
        LANG_PROPS_TO_UPDATE[data] = 1;
        break;
    case "object":
        lang_mixer(LANG_PROPS_TO_UPDATE, data);
    }
    LANG_UPDATE_LAST = 0;
    if (!LANG_UPDATE_INTERVAL) LANG_UPDATE_INTERVAL = setInterval(lang_update_processor, 100);
},
lang_update_processor = function lang_update_processor() { //функция обновления
    var date = new Date;
    for (var l = LANG_QUEUE_TO_UPDATE.length, c, k; LANG_UPDATE_LAST < l; LANG_UPDATE_LAST++) {
        c = LANG_QUEUE_TO_UPDATE[LANG_UPDATE_LAST];
        if(!c)
            continue;
        if (!c._lang || !(c.compareDocumentPosition(BODY) & 0x08)) {
            LANG_QUEUE_TO_UPDATE.splice(LANG_UPDATE_LAST, 1);
            LANG_UPDATE_LAST--;
            if (!LANG_QUEUE_TO_UPDATE.length) break;
            continue;
        }
        for (k in c._lang)
        if (k in LANG_PROPS_TO_UPDATE) lang_set(c, k, c._lang[k]);
        if (!(LANG_UPDATE_LAST % 10) && (new Date() - date > 50)) return;
    }
    LANG_PROPS_TO_UPDATE = {};
    clearInterval(LANG_UPDATE_INTERVAL);
    LANG_UPDATE_INTERVAL = 0;
},
lang_set = function lang_set(html, prop, params) { //установка атрибута элемента
    html[params[0]] = prop in LANG_HASH ? LANG_HASH[prop].replace(/%(\d+)/g, function rep(a, b) {
        return params[b] || "";
    }) : "#" + prop + (params.length > 1 ? "(" + params.slice(1).join(",") + ")" : "");
};

var LANG = function Language(htmlNode, varProps, arrParams) { //связывание элемента с ключами
    var k;
    if (typeof htmlNode != "object") return;
    if (typeof varProps != "object") {
        if (typeof varProps == "string") {
            k = {};
            k[varProps] = [htmlNode.nodeType == 1 ? "innerHTML" : "nodeValue"].
            concat(Array.isArray(arrParams) ? arrParams : [])
            varProps = k;
        } else return;
    }
    if (typeof htmlNode._lang != "object") htmlNode._lang = {};
    for (k in varProps) {
        if (!(Array.isArray(varProps[k]))) varProps[k] = [varProps[k]];
        htmlNode._lang[k] = varProps[k];
        lang_set(htmlNode, k, varProps[k]);
    }
    if (LANG_QUEUE_TO_UPDATE.indexOf(htmlNode) == -1) LANG_QUEUE_TO_UPDATE.push(htmlNode);
};
lang_mixer(LANG, {
get: function get(strProp) { //получение перевода из хэша
    return LANG_HASH[strProp] || ("#" + strProp);
},
set: function set(strProp, strValue, boolSystem) { //установка ключа в пользовательском
    //или системном словаре
    var obj = !boolSystem ? LANG_HASH_USER : LANG_HASH_SYSTEM;
    if (typeof strValue != "string" || !strValue) delete obj[strProp];
    else obj[strProp] = strValue;
    hash_rebuild();
    lang_update(strProp + "");
    return obj[strProp] || null;
},
load: function load(strName, objData) { //загрузка словаря(ей)
    switch (typeof strName) {
    default:
        return null;
    case "string":
        if (LANG_HASH_INDEX[strName]) {
            LANG_JUST_DELETE = true;
            LANG.unload(strName);
            LANG_JUST_DELETE = false;
        }
        LANG_HASH_LIST.push(objData);
        LANG_HASH_INDEX[strName] = objData;
        break;
    case "object":
        objData = {};
        for (var k in strName) {
            if (LANG_HASH_INDEX[k]) {
                LANG_JUST_DELETE = true;
                LANG.unload(k);
                LANG_JUST_DELETE = false;
            }
            LANG_HASH_LIST.push(strName[k]);
            LANG_HASH_INDEX[k] = strName[k];
            objData[k] = 1;
        }

    }
    hash_rebuild();
    lang_update(objData);
    return typeof strName == "string" ? objData : strName;
},
unload: function unload(strName) { //выгрузка словаря(ей)
    var obj, res = {}, i;
    if (!(Array.isArray(strName))) strName = [strName];
    if (!strName.length) return null;
    for (i = strName.length; i--;) {
        obj = LANG_HASH_INDEX[strName[i]];
        if (obj) {
            LANG_HASH_LIST.splice(LANG_HASH_LIST.indexOf(obj), 1);
            delete LANG_HASH_INDEX[strName[i]];
            res[strName[i]] = obj;
            if (LANG_JUST_DELETE) return;
        }
    }
    hash_rebuild();
    lang_update(obj);
    return strName.length == 1 ? res : obj;
},
params: function params(htmlElem, strKey, arrParams) {
    if (typeof htmlElem != "object" || !htmlElem._lang || !htmlElem._lang[strKey]) return false;
    htmlElem._lang[strKey] = htmlElem._lang[strKey].slice(0, 1).concat(Array.isArray(arrParams) ? arrParams : []);
    lang_set(htmlElem, strKey, htmlElem._lang[strKey]);
    return true;
}
});
return LANG;
})();

let oldGlossary = {};
function updateLang(){
    let
        words          = {},
        effMic         = [],
        numb = false;
    (function traverse(root){
        for (let el=root.firstChild; el; el=el.nextSibling){
            if (el.nodeType==3){
                if (el.textContent.match(/EFF_/)){
                    if (el.textContent.match(/. EFF_/)){
                        numb = true;
                        let idx = el.textContent.indexOf('.')
                        words[el.textContent.slice(idx+2, idx+9)]=el;
                        if (el.textContent.match(/🎙/))
                            effMic.push(el.textContent.slice(idx+2, idx+9));
                    }
                    else if(el.textContent.match(/🎙/)){
                        effMic.push(el.textContent.slice(0, 7));
                        words[el.textContent.slice(0, 7)]=el;
                    }
                    else {
                        words[el.textContent]=el;    
                    }
                }
                else
                    continue;
            }
            else
                if(el.childNodes.length)
                    arguments.callee(el);
        }
    })(document.documentElement);
    console.log("WORDS", words);

    httpRequestXload = new XMLHttpRequest();
    httpRequestXload.overrideMimeType('application/json');
    httpRequestXload.onload = (res)=>{
        console.log('--| response');
        // console.log(httpRequestXload.responseText);

        let
            obj      = httpRequestXload.responseText;
            let glossaryEff = {};
        switch (langs) {
            case "eng":
                glossaryEff = JSON.parse( obj ).english;
                break;

            case "rus":
                glossaryEff = JSON.parse( obj ).russian;
                break;
        }

        // console.log("MICC", effMic);
        
        let matchGlossary = {};
        let keyS = Object.keys(glossaryEff);
        if (numb){
            for (let k = 0; k < keyS.length; k++){
                for (let i = 4; i < 7; i++) {
                    if (keyS[k][i] !== "0"){
                        let newNum;
                        newNum = keyS[k].slice(i) + ". " + Object.values(glossaryEff)[k];
                        if (effMic.length) {
                            for (let z = 0; z < effMic.length; z++){
                                if (keyS[k] === effMic[z]){
                                    newNum = keyS[k].slice(i) + ". " + Object.values(glossaryEff)[k] + " 🎙";
                                    break;
                                }
                            }
                        }
                        matchGlossary[keyS[k]] = newNum;
                        break;
                    }
                }
                
            }
        }
        else if (effMic.length && !numb){
            for (let k = 0; k < keyS.length; k++){
                let newn;
                newn = Object.values(glossaryEff)[k];
                for (let z = 0; z < effMic.length; z++){
                    if (keyS[k] === effMic[z]){
                        newn = Object.values(glossaryEff)[k] + " 🎙";
                        break;
                    }
                }
                matchGlossary[keyS[k]] = newn;
            }
        }
        else {
            matchGlossary = glossaryEff;
        }


        // Эта часть может пригодиться для перевода по значению, а не по ключам
        // --| match glossaryEff
        // let matchGlossary = {};

        // Object.keys(words).forEach((v, i)=>{
        //     let
        //         wordsEl     = words[v],
        //         wordsTxt    = wordsEl.nodeValue,
        //         flagMatch   = false,
        //         translation = '';

            // Object.keys(glossaryEff).forEach((v, i)=>{
        //         let testKey = v;

        //         if(wordsTxt==testKey){
        //             flagMatch   = true;
        //             translation = glossaryEff[v];
        //         }
        //     });
            
        //     if(flagMatch){
        //         matchGlossary[v] = translation;
        //     } else {
        //         matchGlossary[v] = wordsTxt;
        //     }
        // });

        console.log(matchGlossary);
        lang.unload("def", oldGlossary);
        lang.load("def", matchGlossary);
        oldGlossary = matchGlossary;

        for(let key in words)
            lang(words[key],key);

    }

    httpRequestXload.open('GET', 'local/glossaryEff.json', true);
    httpRequestXload.send(null);
    }